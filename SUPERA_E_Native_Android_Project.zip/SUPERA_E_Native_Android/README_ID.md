# SUPERA.E. Native Android — Local AI Edition

**Project status:** source project scaffold, not a precompiled APK. This workspace does not contain Android SDK/NDK or the native llama.cpp binaries, so an installable APK has not been built or device-tested here.

## Target configuration

- App: SUPERA.E.
- Native UI: Kotlin + Jetpack Compose, monochrome retro SMS/LCD theme
- Local inference: `llama.kt` (Kotlin/JNI binding backed by llama.cpp)
- Model: Qwen3 1.7B GGUF, Q4_K_M
- ABI: `arm64-v8a`
- Context: 4096 tokens
- Initial inference: CPU, 2 threads, GPU offload disabled for stability
- Memory: chat history stored locally; simple preference capture for explicit phrases such as "ingat ya", "aku suka", "mulai sekarang", and "jangan panggil".
- Model download: automatic on first launch, Wi-Fi only, with SHA-256 verification.

## Requirements on the build computer

1. Android Studio (current stable)
2. JDK 21
3. Android SDK Platform 35
4. Android NDK r27 or newer
5. Git and Bash (Git Bash is sufficient on Windows)

## Prepare native inference dependency

On Windows PowerShell:

```powershell
.\scripts\setup-native-engine.ps1
```

On macOS/Linux:

```bash
./scripts/setup-native-engine.sh
```

This clones `https://github.com/tensai-app/llama.kt`, initializes its pinned submodules, and runs its bootstrap script to vendor the llama.cpp native sources. This step requires internet and can take a while.

## Build the APK

1. Open the `SUPERA_E_Native_Android` folder in Android Studio.
2. Set Gradle JDK to JDK 21 (Settings → Build Tools → Gradle).
3. Install Android SDK Platform 35 and NDK r27+ from SDK Manager.
4. Sync the project.
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Android Studio will produce a debug APK at:

   `app/build/outputs/apk/debug/app-debug.apk`

7. Copy that APK to the Redmi Note 14 and install it. Allow installation from the file manager when Android asks.

The first launch starts the Qwen3 model download. The model is approximately 1.28 GB (about 1.19 GiB). Download is restricted to unmetered Wi-Fi to avoid unexpectedly consuming mobile data. Keep the app open until DownloadManager finishes. The app verifies the file SHA-256 before loading it.

After the first download and successful model load, airplane mode can be enabled and chat inference runs locally. Android INTERNET permission remains in the manifest solely for the first model download; inference code does not send prompts to a server.

## Model provenance

- Repository: https://huggingface.co/tauqir02/Qwen3-1.7B-GGUF
- File: `Qwen3-1.7B-Q4_K_M.gguf`
- Expected size: 1,282,439,552 bytes
- SHA-256: `b7a7dfc98e59b4ceb2abaa822c683ec9c2471ff4c54db7536eaa5008c38432af`
- The GGUF conversion is based on Qwen3 1.7B. Review the model card and license terms at the repository before redistribution.

## Notes / limitations

- Local models are less capable than cloud ChatGPT models, especially on complex reasoning, long documents, and current information.
- This initial build stores the complete conversation locally and automatically saves a limited set of explicit preference statements. It does not yet implement semantic/vector memory or automatic summarization of all old conversations.
- Voice, file ingestion, export/backup, and advanced memory management are future milestones.
- On an 8 GB phone, Android and other apps share RAM. If the app is killed or feels slow, close background apps. The initial 4096-token context and 2 CPU threads are conservative starting settings, not a guarantee of identical performance on every Redmi Note 14 variant.
- The llama.kt binding is a third-party open-source dependency. Its source and license are available at https://github.com/tensai-app/llama.kt.

## Build from terminal (optional)

After the native engine setup and Android SDK/NDK installation:

- Windows PowerShell: `.\scripts\build-apk.ps1`
- macOS/Linux: `./scripts/build-apk.sh`

The helper downloads Gradle 8.9 into the user's home cache if needed, then runs `:app:assembleDebug`. Android SDK location must be available through `ANDROID_HOME` / `ANDROID_SDK_ROOT` or Android Studio's `local.properties`.
