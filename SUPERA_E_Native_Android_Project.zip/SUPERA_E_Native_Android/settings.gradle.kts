pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories { google(); mavenCentral() }
}
rootProject.name = "SUPERA.E."
include(":app")
include(":llama-kt")
project(":llama-kt").projectDir = file("third_party/llama.kt/llama-kt")
