package com.superae.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class MemoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("superae_local_memory", Context.MODE_PRIVATE)

    data class Turn(val role: String, val content: String)

    fun allTurns(): List<Turn> {
        val arr = JSONArray(prefs.getString("turns", "[]"))
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            Turn(o.optString("role"), o.optString("content"))
        }
    }

    fun addTurn(role: String, content: String) {
        val arr = JSONArray(prefs.getString("turns", "[]"))
        arr.put(JSONObject().put("role", role).put("content", content).put("at", System.currentTimeMillis()))
        prefs.edit().putString("turns", arr.toString()).apply()
        if (role == "user") maybeRemember(content)
    }

    fun recentTurns(limit: Int = 12): List<Turn> = allTurns().takeLast(limit)

    fun memories(): List<String> {
        val arr = JSONArray(prefs.getString("memories", "[]"))
        return (0 until arr.length()).map { arr.optString(it) }
    }

    private fun maybeRemember(text: String) {
        val s = text.trim()
        val lower = s.lowercase()
        val cues = listOf("ingat bahwa", "ingat ya", "mulai sekarang", "aku suka", "saya suka", "gw suka", "gue suka", "aku tidak suka", "saya tidak suka", "preferensi saya", "preferensi gw", "jangan panggil", "panggil saya")
        if (cues.any { lower.contains(it) } && s.length in 8..240) {
            val arr = JSONArray(prefs.getString("memories", "[]"))
            val existing = (0 until arr.length()).map { arr.optString(it) }
            if (s !in existing) {
                arr.put(s)
                while (arr.length() > 50) arr.remove(0)
                prefs.edit().putString("memories", arr.toString()).apply()
            }
        }
    }

    fun clearTurns() = prefs.edit().remove("turns").apply()
    fun clearMemories() = prefs.edit().remove("memories").apply()
}
