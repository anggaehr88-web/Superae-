package com.superae.app

import android.app.DownloadManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tensai.llamakt.ChatMessage
import com.tensai.llamakt.LlamaEngine
import com.tensai.llamakt.SamplingParams
import com.tensai.llamakt.chat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val lcd = Color(0xFFAEB8AD)
private val lcdPanel = Color(0xFFCBD4C8)
private val lcdPaper = Color(0xFFEEF1E9)
private val lcdInk = Color(0xFF172117)
private val lcdMuted = Color(0xFF4D594C)
private val lcdLine = Color(0xFF657265)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SuperaeApp(this) }
    }
}

@Composable
private fun SuperaeApp(activity: MainActivity) {
    val context = activity
    val store = remember { MemoryStore(context) }
    val scope = rememberCoroutineScope()
    var turns by remember { mutableStateOf(store.allTurns()) }
    var input by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("MEMORY CHECK") }
    var progress by remember { mutableIntStateOf(0) }
    var modelReady by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var showMemories by remember { mutableStateOf(false) }
    var memories by remember { mutableStateOf(store.memories()) }
    var engine by remember { mutableStateOf<LlamaEngine?>(null) }
    var downloadId by remember { mutableStateOf<Long?>(null) }

    fun refresh() { turns = store.allTurns(); memories = store.memories() }

    LaunchedEffect(Unit) {
        val existing = LocalModel.modelFile(context)
        if (existing.exists() && existing.length() == LocalModel.EXPECTED_BYTES) {
            val valid = LocalModel.verifySha256(existing)
            if (!valid) existing.delete() else modelReady = true
        }
        if (!modelReady) {
            status = "DOWNLOADING MODEL · WI-FI"
            downloadId = LocalModel.startDownload(context)
        }
    }

    LaunchedEffect(downloadId) {
        val id = downloadId ?: return@LaunchedEffect
        while (true) {
            val (pct, state) = LocalModel.progress(context, id)
            progress = pct
            when (state) {
                DownloadManager.STATUS_SUCCESSFUL -> {
                    val valid = LocalModel.verifySha256(LocalModel.modelFile(context))
                    if (valid) {
                        modelReady = true
                        status = "MODEL VERIFIED · LOADING"
                    } else {
                        LocalModel.modelFile(context).delete()
                        status = "MODEL CHECKSUM FAILED · RETRY"
                    }
                    break
                }
                DownloadManager.STATUS_FAILED -> { status = "DOWNLOAD FAILED · CHECK WI-FI"; break }
                else -> delay(1000)
            }
        }
    }

    LaunchedEffect(modelReady) {
        if (modelReady && engine == null) {
            status = "LOADING LOCAL AI"
            try {
                val e = withContext(Dispatchers.IO) {
                    LlamaEngine().also { it.load(path = LocalModel.modelFile(context).absolutePath, nGpuLayers = 0, nCtx = 4096, nThreads = 2) }
                }
                engine = e
                status = "LOCAL AI READY · OFFLINE"
                if (store.allTurns().isEmpty()) {
                    store.addTurn("assistant", "Halo, Angga. SUPERA.E. sudah aktif. Model lokal berhasil dimuat. Silakan mulai percakapan. Dan ya, aku tetap akan mengingatkan kalau 27 tab browser bukan strategi produktivitas.")
                    refresh()
                }
            } catch (t: Throwable) {
                status = "ENGINE ERROR · ${t.message?.take(70) ?: "UNKNOWN"}"
            }
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(background = lcd, surface = lcdPanel, primary = lcdInk, onPrimary = lcdPaper)) {
        Column(Modifier.fillMaxSize().background(lcd).padding(12.dp)) {
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("SUPERA.E.", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, fontSize = 22.sp, color = lcdInk, letterSpacing = 2.sp)
                    Text("PERSONAL INTELLIGENCE SYSTEM", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = lcdMuted)
                }
                Text("▣ LOCAL", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = lcdInk, modifier = Modifier.background(lcdPanel, RoundedCornerShape(3.dp)).padding(7.dp))
            }
            HorizontalDivider(color = lcdLine, thickness = 2.dp)
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("✉ MESSAGES / INBOX", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = lcdInk)
                Text("SMS TERMINAL", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = lcdMuted)
            }
            Row(Modifier.fillMaxWidth().background(Color(0xFF526052), RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp)).padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("SUPERA.E. MESSAGES", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("GSM · OFFLINE", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
            }
            Row(Modifier.fillMaxWidth().background(lcdPaper).padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("[S]", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = lcdInk, modifier = Modifier.background(lcdPanel).padding(7.dp))
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text("SUPERA.E.", color = lcdInk, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(status, color = lcdMuted, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                }
                Text("MEM", color = lcdMuted, fontFamily = FontFamily.Monospace, fontSize = 9.sp, modifier = Modifier.padding(4.dp))
            }
            if (!modelReady) {
                Column(Modifier.fillMaxWidth().background(lcdPaper).padding(14.dp)) {
                    Text("FIRST START · MODEL DOWNLOAD", color = lcdInk, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth(), color = lcdInk, trackColor = lcdPanel)
                    Text("$progress% · Qwen3 1.7B Q4_K_M · ~1.2 GB", color = lcdMuted, fontFamily = FontFamily.Monospace, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
                    Text("Unduhan otomatis menggunakan Wi-Fi. Setelah selesai, model berjalan lokal.", color = lcdMuted, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                    if (status.contains("FAILED") || status.contains("RETRY")) {
                        TextButton(onClick = { status = "RETRYING DOWNLOAD"; progress = 0; downloadId = LocalModel.startDownload(context) }) {
                            Text("RETRY DOWNLOAD", color = lcdInk, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
            LazyColumn(Modifier.weight(1f).fillMaxWidth().background(lcdPaper).padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(turns) { turn ->
                    val isUser = turn.role == "user"
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (isUser) Alignment.End else Alignment.Start) {
                        Text(if (isUser) "ANGGA · ${clockNow()}" else "SUPERA.E. · ${clockNow()}", color = lcdMuted, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                        Text(turn.content, color = lcdInk, fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 18.sp,
                            modifier = Modifier.widthIn(max = 310.dp).background(if (isUser) Color(0xFFC1CBBD) else Color(0xFFEEF1E9), RoundedCornerShape(2.dp)).padding(10.dp))
                    }
                }
                if (busy) item { Text("SUPERA.E. IS TYPING... ▌", color = lcdMuted, fontFamily = FontFamily.Monospace, fontSize = 10.sp) }
            }
            Row(Modifier.fillMaxWidth().background(lcdPanel).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                BasicTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f).background(lcdPaper, RoundedCornerShape(2.dp)).padding(12.dp), textStyle = androidx.compose.ui.text.TextStyle(color = lcdInk, fontFamily = FontFamily.Monospace, fontSize = 13.sp), singleLine = false, maxLines = 3, decorationBox = { inner -> if (input.isEmpty()) Text("Type your message...", color = lcdMuted, fontFamily = FontFamily.Monospace, fontSize = 12.sp); inner() })
                Spacer(Modifier.width(7.dp))
                Button(onClick = {
                    val text = input.trim()
                    if (text.isNotEmpty() && !busy && engine != null) {
                        input = ""
                        store.addTurn("user", text); refresh(); busy = true
                        scope.launch {
                            try {
                                val memoriesNow = store.memories().takeLast(20).joinToString("\n")
                                val system = "You are SUPERA.E., an offline personal AI assistant. Speak Indonesian naturally unless user uses another language. Personality: relaxed, witty, intelligent, occasionally dry-sarcastic, never rude. Be honest, challenge weak assumptions kindly. Address the user as Angga when natural. Remember preferences from this conversation.\nSaved user memories:\n$memoriesNow\nKeep answers useful and appropriately concise. Do not claim internet access."
                                val chatHistory = store.recentTurns(14).map { ChatMessage(it.role, it.content) }.toMutableList()
                                chatHistory.add(0, ChatMessage("system", system))
                                val reply = StringBuilder()
                                withContext(Dispatchers.Default) {
                                    engine!!.chat(chatHistory, SamplingParams(nPredict = 512, temperature = 0.7f, topK = 30, topP = 0.9f), enableThinking = false).collect { token -> reply.append(token) }
                                }
                                val answer = reply.toString().trim().ifBlank { "Maaf, generasi jawaban berhenti sebelum menghasilkan teks. Coba kirim ulang." }
                                store.addTurn("assistant", answer); refresh()
                            } catch (t: Throwable) {
                                store.addTurn("assistant", "Ada gangguan pada mesin lokal: ${t.message ?: "unknown error"}. Coba lagi setelah model dimuat ulang."); refresh()
                            } finally { busy = false }
                        }
                    }
                }, enabled = !busy && engine != null, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF526052), contentColor = Color.White), shape = RoundedCornerShape(2.dp), contentPadding = PaddingValues(horizontal = 15.dp, vertical = 12.dp)) { Text("➤", fontFamily = FontFamily.Monospace) }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("LOCAL AI · NO API · NO CLOUD", color = lcdMuted, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                TextButton(onClick = { showMemories = true }) { Text("MEMORY (${memories.size})", color = lcdInk, fontFamily = FontFamily.Monospace, fontSize = 9.sp) }
                TextButton(onClick = { store.clearTurns(); refresh() }) { Text("CLEAR CHAT", color = lcdInk, fontFamily = FontFamily.Monospace, fontSize = 9.sp) }
            }
        }
    }

    if (showMemories) {
        AlertDialog(onDismissRequest = { showMemories = false }, containerColor = lcdPanel,
            title = { Text("LOCAL MEMORY", fontFamily = FontFamily.Monospace, color = lcdInk) },
            text = { Column {
                if (memories.isEmpty()) Text("Belum ada preferensi yang tersimpan otomatis.", color = lcdInk, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                memories.forEach { Text("• $it", color = lcdInk, fontFamily = FontFamily.Monospace, fontSize = 11.sp, modifier = Modifier.padding(vertical = 3.dp)) }
            } },
            confirmButton = { TextButton(onClick = { store.clearMemories(); refresh(); showMemories = false }) { Text("CLEAR MEMORY", color = lcdInk) } },
            dismissButton = { TextButton(onClick = { showMemories = false }) { Text("CLOSE", color = lcdInk) } })
    }
}

private fun clockNow(): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
