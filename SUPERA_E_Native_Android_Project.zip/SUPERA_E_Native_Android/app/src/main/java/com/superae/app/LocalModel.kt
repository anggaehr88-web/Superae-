package com.superae.app

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest

object LocalModel {
    const val FILE_NAME = "Qwen3-1.7B-Q4_K_M.gguf"
    const val MODEL_URL = "https://huggingface.co/tauqir02/Qwen3-1.7B-GGUF/resolve/main/Qwen3-1.7B-Q4_K_M.gguf"
    const val SHA256 = "b7a7dfc98e59b4ceb2abaa822c683ec9c2471ff4c54db7536eaa5008c38432af"
    const val EXPECTED_BYTES = 1_282_439_552L

    fun modelFile(context: Context): File = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), FILE_NAME)

    fun isReady(context: Context): Boolean {
        val f = modelFile(context)
        return f.exists() && f.length() == EXPECTED_BYTES
    }

    fun startDownload(context: Context): Long {
        modelFile(context).takeIf { it.exists() }?.delete()
        val request = DownloadManager.Request(Uri.parse(MODEL_URL))
            .setTitle("SUPERA.E. AI model")
            .setDescription("Mengunduh Qwen3 1.7B Q4_K_M (sekitar 1,2 GB). Disarankan Wi-Fi.")
            .setMimeType("application/octet-stream")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(false)
            .setAllowedOverRoaming(false)
            .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, FILE_NAME)
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        return manager.enqueue(request)
    }

    suspend fun progress(context: Context, id: Long): Pair<Int, Int> = withContext(Dispatchers.IO) {
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val query = DownloadManager.Query().setFilterById(id)
        manager.query(query).use { c ->
            if (!c.moveToFirst()) return@withContext 0 to DownloadManager.STATUS_FAILED
            val soFar = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
            val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
            val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            val pct = if (total > 0) ((soFar * 100) / total).toInt() else 0
            pct to status
        }
    }

    suspend fun verifySha256(file: File): Boolean = withContext(Dispatchers.IO) {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                digest.update(buffer, 0, n)
            }
        }
        digest.digest().joinToString("") { "%02x".format(it) } == SHA256
    }
}
