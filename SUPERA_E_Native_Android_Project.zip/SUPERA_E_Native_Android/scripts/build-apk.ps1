$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$GradleVersion = '8.9'
$Cache = Join-Path $env:USERPROFILE '.superae\gradle'
$GradleHome = Join-Path $Cache "gradle-$GradleVersion"
$GradleExe = Join-Path $GradleHome 'bin\gradle.bat'
New-Item -ItemType Directory -Force -Path $Cache | Out-Null
if (-not (Test-Path $GradleExe)) {
    $Zip = Join-Path $Cache "gradle-$GradleVersion-bin.zip"
    Invoke-WebRequest "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip" -OutFile $Zip
    Expand-Archive -Path $Zip -DestinationPath $Cache -Force
}
Push-Location $Root
try {
    & $GradleExe --no-daemon :app:assembleDebug
    Write-Host "APK: $Root\app\build\outputs\apk\debug\app-debug.apk"
} finally { Pop-Location }
