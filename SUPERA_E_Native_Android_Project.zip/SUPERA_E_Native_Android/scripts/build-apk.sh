#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
GRADLE_VERSION=8.9
CACHE="$HOME/.superae/gradle"
GRADLE_HOME="$CACHE/gradle-$GRADLE_VERSION"
mkdir -p "$CACHE"
if [ ! -x "$GRADLE_HOME/bin/gradle" ]; then
  curl -L "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" -o "$CACHE/gradle-$GRADLE_VERSION-bin.zip"
  unzip -q -o "$CACHE/gradle-$GRADLE_VERSION-bin.zip" -d "$CACHE"
fi
cd "$ROOT"
"$GRADLE_HOME/bin/gradle" --no-daemon :app:assembleDebug
printf 'APK: %s\n' "$ROOT/app/build/outputs/apk/debug/app-debug.apk"
