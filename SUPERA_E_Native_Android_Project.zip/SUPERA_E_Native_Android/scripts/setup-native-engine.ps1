$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$ThirdParty = Join-Path $Root 'third_party'
$Repo = Join-Path $ThirdParty 'llama.kt'
New-Item -ItemType Directory -Force -Path $ThirdParty | Out-Null
if (-not (Test-Path (Join-Path $Repo '.git'))) {
    git clone https://github.com/tensai-app/llama.kt $Repo
}
git -C $Repo submodule update --init --recursive
bash (Join-Path $Repo 'scripts/bootstrap.sh')
Write-Host 'Native engine prepared. Open this folder in Android Studio and sync Gradle.'
