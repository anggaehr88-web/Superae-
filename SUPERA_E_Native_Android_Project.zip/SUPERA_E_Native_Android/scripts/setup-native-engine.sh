#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/third_party"
if [ ! -d "$ROOT/third_party/llama.kt/.git" ]; then
  git clone https://github.com/tensai-app/llama.kt "$ROOT/third_party/llama.kt"
fi
git -C "$ROOT/third_party/llama.kt" submodule update --init --recursive
bash "$ROOT/third_party/llama.kt/scripts/bootstrap.sh"
echo "Native engine prepared. Open this folder in Android Studio and sync Gradle."
